#!/bin/bash
# Brain Training Game - OpenClaw Complete Setup Script
# Run this tomorrow after installing OpenClaw
# Estimated time: 30 minutes

set -e  # Exit on error

echo "🧠 BRAIN TRAINING GAME - OpenClaw Setup"
echo "========================================"
echo ""

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if OpenClaw is installed
if ! command -v openclaw &> /dev/null; then
    echo -e "${RED}❌ OpenClaw not found${NC}"
    echo "Please install first:"
    echo "  curl -fsSL https://openclaw.sh/install.sh | bash"
    exit 1
fi

echo -e "${GREEN}✅ OpenClaw detected${NC}"
echo ""

# Function to prompt for input
prompt() {
    echo -e "${YELLOW}$1${NC}"
    read -p "> " value
    echo "$value"
}

# Function to prompt for secret
prompt_secret() {
    echo -e "${YELLOW}$1${NC}"
    read -sp "> " value
    echo ""
    echo "$value"
}

echo "📋 STEP 1: Configuration"
echo "========================"
echo ""

# Anthropic API Key
ANTHROPIC_KEY=$(prompt "Enter your Anthropic API key (sk-ant-xxx...):")
openclaw config set ANTHROPIC_API_KEY "$ANTHROPIC_KEY"
echo -e "${GREEN}✅ Claude API configured${NC}"
echo ""

# GitHub Configuration
GITHUB_TOKEN=$(prompt "Enter your GitHub personal access token (ghp_xxx...):")
GITHUB_REPO=$(prompt "Enter your GitHub repo (username/repo-name):")
openclaw config set GITHUB_TOKEN "$GITHUB_TOKEN"
openclaw config set GITHUB_REPO "$GITHUB_REPO"
echo -e "${GREEN}✅ GitHub configured${NC}"
echo ""

# Upwork Configuration  
echo "Have you posted the Upwork job yet? (y/n)"
read -p "> " upwork_posted

if [ "$upwork_posted" = "y" ]; then
    UPWORK_JOB_ID=$(prompt "Enter Upwork job ID (from URL, starts with ~):")
    UPWORK_USER=$(prompt "Enter Upwork email/username:")
    UPWORK_PASS=$(prompt_secret "Enter Upwork password:")
    
    openclaw config set UPWORK_JOB_ID "$UPWORK_JOB_ID"
    openclaw config set UPWORK_USERNAME "$UPWORK_USER"
    openclaw config set UPWORK_PASSWORD "$UPWORK_PASS"
    echo -e "${GREEN}✅ Upwork configured${NC}"
else
    echo -e "${YELLOW}⏭️  Skipping Upwork (configure later)${NC}"
fi
echo ""

# Figma Configuration (optional)
echo "Have you hired a designer with Figma? (y/n)"
read -p "> " has_designer

if [ "$has_designer" = "y" ]; then
    FIGMA_TOKEN=$(prompt "Enter Figma personal access token:")
    FIGMA_FILE=$(prompt "Enter Figma file ID (from URL):")
    
    openclaw config set FIGMA_TOKEN "$FIGMA_TOKEN"
    openclaw config set FIGMA_FILE_ID "$FIGMA_FILE"
    echo -e "${GREEN}✅ Figma configured${NC}"
else
    echo -e "${YELLOW}⏭️  Skipping Figma (configure later)${NC}"
fi
echo ""

echo "📦 STEP 2: Installing Skills"
echo "============================="
echo ""

# Create skills directory
mkdir -p ~/.openclaw/skills/brain-game/

# Copy skills (assumes they're in current directory)
echo "Copying skill files..."
cp skills/*.skill.md ~/.openclaw/skills/brain-game/ 2>/dev/null || {
    echo -e "${YELLOW}⚠️  Skill files not found in current directory${NC}"
    echo "Please copy them manually to: ~/.openclaw/skills/brain-game/"
    echo "Files needed:"
    echo "  - upwork-recruiter.skill.md"
    echo "  - github-pm.skill.md"
    echo "  - designer-manager.skill.md"
    read -p "Press enter when done..."
}

echo ""
echo "Enabling skills..."

# Enable GitHub PM skill (always)
openclaw skill enable brain-game/github-pm
openclaw schedule brain-game/github-pm "0 9 * * *"
openclaw watch brain-game/github-pm --realtime
echo -e "${GREEN}✅ GitHub PM skill enabled${NC}"

# Enable Upwork skill (if configured)
if [ "$upwork_posted" = "y" ]; then
    openclaw skill enable brain-game/upwork-recruiter
    openclaw schedule brain-game/upwork-recruiter "0 */2 * * *"
    echo -e "${GREEN}✅ Upwork recruiter skill enabled${NC}"
fi

# Enable Designer skill (if configured)
if [ "$has_designer" = "y" ]; then
    openclaw skill enable brain-game/designer-manager
    openclaw schedule brain-game/designer-manager "0 10 * * *"
    echo -e "${GREEN}✅ Designer manager skill enabled${NC}"
fi

echo ""
echo "📱 STEP 3: Connecting Messaging"
echo "================================"
echo ""

echo "Which messaging app do you want to use?"
echo "1) Telegram (recommended)"
echo "2) WhatsApp"
echo "3) Discord"
echo "4) Skip for now"
read -p "> " messaging_choice

case $messaging_choice in
    1)
        openclaw connect telegram
        ;;
    2)
        openclaw connect whatsapp
        ;;
    3)
        DISCORD_WEBHOOK=$(prompt "Enter Discord webhook URL:")
        openclaw connect discord --webhook "$DISCORD_WEBHOOK"
        ;;
    *)
        echo -e "${YELLOW}⏭️  Skipping messaging (configure later)${NC}"
        ;;
esac

echo ""
echo "🧪 STEP 4: Testing Setup"
echo "========================"
echo ""

echo "Running tests..."

# Test Claude API
echo -n "Testing Claude API... "
if openclaw chat "Hello, respond with 'working' if you can see this" | grep -q "working"; then
    echo -e "${GREEN}✅ Working${NC}"
else
    echo -e "${RED}❌ Failed${NC}"
fi

# Test GitHub connection
echo -n "Testing GitHub connection... "
if openclaw run brain-game/github-pm test &> /dev/null; then
    echo -e "${GREEN}✅ Working${NC}"
else
    echo -e "${RED}❌ Failed${NC}"
fi

# Test messaging
echo -n "Testing notifications... "
openclaw notify test "OpenClaw setup complete! 🎉"
echo -e "${GREEN}✅ Check your messaging app${NC}"

echo ""
echo "🎬 STEP 5: Final Setup"
echo "======================"
echo ""

# Set permissions
echo "Setting security permissions..."
openclaw permissions lock --action merge_pr
openclaw permissions lock --action spend_money
openclaw permissions lock --action delete_data
openclaw permissions require-approval --action hire_candidate
echo -e "${GREEN}✅ Security configured${NC}"

echo ""
echo "==================================="
echo "🎉 SETUP COMPLETE!"
echo "==================================="
echo ""
echo "What happens next:"
echo ""
echo "1. ✅ OpenClaw is now monitoring:"
if [ "$upwork_posted" = "y" ]; then
    echo "   • Upwork (every 2 hours)"
fi
echo "   • GitHub (real-time)"
if [ "$has_designer" = "y" ]; then
    echo "   • Figma (daily at 10 AM)"
fi
echo ""
echo "2. 📱 You'll receive daily reports at 9 AM"
echo ""
echo "3. 🎯 Next actions:"
echo "   • Post Upwork job (if not done)"
echo "   • Create GitHub repo with project files"
echo "   • Hire designer (if not done)"
echo ""
echo "4. 💬 Talk to OpenClaw:"
echo "   • \"status\" - Get current status"
echo "   • \"help\" - See all commands"
echo "   • \"check [service]\" - Manual check"
echo ""
echo "📚 Documentation:"
echo "   • Setup guide: openclaw-package/docs/MASTER_SETUP_GUIDE.md"
echo "   • Skills docs: openclaw-package/skills/"
echo ""
echo "🐛 Troubleshooting:"
echo "   • View logs: openclaw logs"
echo "   • Check status: openclaw status"
echo "   • Restart: openclaw restart"
echo ""
echo "🚀 OpenClaw is running 24/7 in the background!"
echo ""

# Save configuration summary
cat > ~/.openclaw/brain-game-config.txt <<EOF
Brain Training Game Project - OpenClaw Configuration
Generated: $(date)

GitHub Repo: $GITHUB_REPO
Upwork Job ID: ${UPWORK_JOB_ID:-Not configured}
Figma File: ${FIGMA_FILE:-Not configured}

Skills Enabled:
- GitHub PM: ✅ (Daily reports at 9 AM)
$([ "$upwork_posted" = "y" ] && echo "- Upwork Recruiter: ✅ (Every 2 hours)" || echo "- Upwork Recruiter: ⏭️ Skipped")
$([ "$has_designer" = "y" ] && echo "- Designer Manager: ✅ (Daily at 10 AM)" || echo "- Designer Manager: ⏭️ Skipped")

Messaging: ${messaging_choice}

Next Steps:
1. Verify you received test notification
2. Post jobs if not done
3. Create GitHub repo if not done
4. Wait for daily report tomorrow at 9 AM
EOF

echo "Configuration saved to: ~/.openclaw/brain-game-config.txt"
echo ""
echo "✨ You're all set! Let OpenClaw handle the rest."
echo ""